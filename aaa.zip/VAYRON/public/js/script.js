/**
 * VAYRON — Luxury Digital Experience Engine
 */

document.addEventListener('DOMContentLoaded', () => {
    initNavigation();
    initScrollProgress();
    initCursorGlow();
    initBrandFilter();
    initYear();
});

// 1. Navbar Sticky & Mobile Menu Toggle
function initNavigation() {
    const menuToggle = document.getElementById('menuToggle');
    const navLinks = document.getElementById('navLinks');
    const links = document.querySelectorAll('.nav-link');

    if (menuToggle && navLinks) {
        menuToggle.addEventListener('click', () => {
            const isOpen = navLinks.classList.toggle('active');
            menuToggle.setAttribute('aria-expanded', isOpen);
        });

        links.forEach(link => {
            link.addEventListener('click', () => {
                navLinks.classList.remove('active');
                menuToggle.setAttribute('aria-expanded', 'false');
            });
        });
    }
}

// 2. Scroll Progress Line
function initScrollProgress() {
    const progress = document.getElementById('pageProgress');
    if (!progress) return;

    window.addEventListener('scroll', () => {
        const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
        const scrolled = (window.scrollY / height) * 100;
        progress.style.width = `${scrolled}%`;
    });
}

// 3. Smooth Ambient Cursor Follower
function initCursorGlow() {
    const glow = document.getElementById('cursorGlow');
    if (!glow || window.matchMedia('(pointer: coarse)').matches) return;

    let targetX = window.innerWidth / 2;
    let targetY = window.innerHeight / 2;
    let currentX = targetX;
    let currentY = targetY;

    window.addEventListener('mousemove', (e) => {
        targetX = e.clientX;
        targetY = e.clientY;
    });

    function animate() {
        currentX += (targetX - currentX) * 0.12;
        currentY += (targetY - currentY) * 0.12;
        glow.style.transform = `translate(${currentX}px, ${currentY}px)`;
        requestAnimationFrame(animate);
    }
    animate();
}

// 4. Category Filtering for Brands
function initBrandFilter() {
    const filterBtns = document.querySelectorAll('.filter-btn');
    const cards = document.querySelectorAll('.brand-card');

    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            filterBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            const filter = btn.getAttribute('data-filter');

            cards.forEach(card => {
                const category = card.getAttribute('data-category');
                if (filter === 'all' || category === filter) {
                    card.classList.remove('hidden');
                } else {
                    card.classList.add('hidden');
                }
            });
        });
    });
}

// 5. Atelier Drawer Data & Functions
const brandDetails = {
    alhaya: {
        title: "AL HAYA",
        category: "HAUTE MODEST FASHION",
        desc: "Maison dedicated to elevating modest expression. Crafting luxurious Japanese silk abayas, layered draping, and contemporary silhouettes that represent timeless grace and privacy.",
        specs: {
            "Foundation": "London / Dubai",
            "Specialization": "Modest Couture & Abayas",
            "Signature Material": "Japanese Nidha Silk & Organza",
            "Status": "Active Collection"
        },
        link: "https://al-haya-4286e.web.app/"
    },
    perfume: {
        title: "YOUR PERFUME BRAND",
        category: "NICHE EXTRACTS & ATTARS",
        desc: "An exploration of sensory depth. Developing private extract collections featuring pure Cambodian oud, amber accord, and cold-distilled floral extractions.",
        specs: {
            "Concentration": "Extrait de Parfum (30%)",
            "Specialization": "Niche & Bespoke Scents",
            "Craft Method": "Cold Organic Maceration",
            "Status": "Vaulted Editions"
        },
        link: "#brands"
    },
    shoes: {
        title: "YOUR SHOE BRAND",
        category: "ARCHITECTURAL FOOTWEAR",
        desc: "Bridging the gap between structural footwear and daily ergonomics. Hand-welted full-grain leathers sculpted with minimalist lines.",
        specs: {
            "Origin": "Atelier Handcrafted",
            "Leather": "Vegetable Tanned Calfskin",
            "Sole Construction": "Reinforced Geometric Vibram",
            "Status": "Limited Run"
        },
        link: "#brands"
    },
    zylux: {
        title: "ZYLUX LIFESTYLE",
        category: "HEAVYWEIGHT CAPSULES",
        desc: "Pure wardrobe architecture. 450 GSM structured loopback fleece, custom combed long-staple cottons, and clean minimal tailoring.",
        specs: {
            "Fabric": "450 GSM Combed Cotton",
            "Dye Process": "Pigment Garment Wash",
            "Fit Profile": "Drop-Shoulder Structural Cut",
            "Status": "Core Collection"
        },
        link: "#brands"
    }
};

window.openDrawer = function(brandKey) {
    const data = brandDetails[brandKey];
    if (!data) return;

    const drawerBody = document.getElementById('drawerBody');
    const drawer = document.getElementById('brandDrawer');
    const overlay = document.getElementById('drawerOverlay');

    let specsHtml = '<ul class="drawer-spec-list">';
    for (let key in data.specs) {
        specsHtml += `<li><span>${key}</span><span>${data.specs[key]}</span></li>`;
    }
    specsHtml += '</ul>';

    drawerBody.innerHTML = `
        <span class="drawer-tag">${data.category}</span>
        <h3>${data.title}</h3>
        <p>${data.desc}</p>
        ${specsHtml}
        <a href="${data.link}" target="_blank" rel="noopener noreferrer" class="btn btn-gold" style="width:100%; justify-content:center; margin-top:20px;">
            <span>Launch Maison Experience</span>
            <span>&nearr;</span>
        </a>
    `;

    overlay.classList.add('active');
    drawer.classList.add('active');
    document.body.style.overflow = 'hidden';
};

window.closeDrawer = function() {
    const drawer = document.getElementById('brandDrawer');
    const overlay = document.getElementById('drawerOverlay');

    if (drawer && overlay) {
        drawer.classList.remove('active');
        overlay.classList.remove('active');
        document.body.style.overflow = 'auto';
    }
};

// 6. Dynamic Year
function initYear() {
    const el = document.getElementById('year');
    if (el) el.textContent = new Date().getFullYear();
}